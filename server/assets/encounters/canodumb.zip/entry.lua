local character_id = "com.discord.Konstinople#7692.enemy.canodumb"

function battle_init(mob)
  mob
      :create_spawner(character_id, Rank.V1)
      :spawn_at(4, 2)

  mob
      :create_spawner(character_id, Rank.V2)
      :spawn_at(6, 1)

  mob
      :create_spawner(character_id, Rank.V3)
      :spawn_at(6, 3)
end
