function package_requires_scripts()
    -- Tries to fetch the scripted character from the engine by namespace
    -- Note: most scripts won't have access to the files outside of the mod
    --       so it is expected that the fetch might fail and we do not spawn the enemy
    --       TODO: mark this file for loading later until all scripts are read to resolve this issue?

    -- Creates a new namespace to the script and contents
    -- Note: if conflicts will throw
    Engine.define_character("com.claris.temp.Swordy", _modpath.."characters/swordy")
end

function package_init(package)
    package:declare_package_id("com.claris.temp.Swordy")
    package:set_name("Timefreeze Swordy")
    package:set_description("I think Swordy is pretty cool.")
    package:set_speed(1)
    package:set_attack(80)
    package:set_health(90)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    local texPath = _modpath.."background.png"
    local animPath = _modpath.."background.animation"
    mob:set_background(texPath, animPath, -1.4, 0.0)
    mob:stream_music(_modpath.."music.ogg", 6579, 76000)

    local duo_spawner = mob:create_spawner("com.claris.temp.Swordy", Rank.V1)
    duo_spawner:spawn_at(5, 2)
end