nonce = function() end 

local texture = nil
local anim = nil
local flame = nil

function move_state(self, dt) 
	next_state()
end

function package_init(self)
    aiStateIndex = 1
    aiState = { 
		time_freeze_state,
	}
	texture = Engine.load_texture(_modpath.."swordy.png")
    self:set_name("Swordy")
    self:set_health(90)
    self:set_texture(texture, true)
    self:set_explosion_behavior(4, 1.0, true)

    anim = self:get_animation()
    anim:load(_modpath.."swordy.animation")
    anim:set_state("IDLE")
	anim:set_playback(Playback.Once)

    self.update_func = on_update
    self.battle_start_func = on_battle_start
    self.battle_end_func = on_battle_end
    self.on_spawn_func = on_spawn
    self.can_move_to_func = can_move_to
    self.delete_func = on_delete
    
    print("done")
end

function next_state()
    -- increment our AI state counter
    aiStateIndex = aiStateIndex + 1
    if aiStateIndex > #aiState then 
        aiStateIndex = 1
    end
end

function time_freeze_state(self, dt)
	local action = Battle.CardAction.new(self, "IDLE")
	local props = action:copy_metadata()
	props.shortname = "GoingRoad"
    props.damage = 0
    props.time_freeze = true
    props.element = Element.None
    props.description = "Send foe to back row!"
	action:set_metadata(props)
	action.execute_func = function(self, dt)
	end
	self:card_action_event(action, ActionOrder.Voluntary)
	next_state()
end

function on_update(self, dt)
    aiState[aiStateIndex](self, dt)
end

function on_battle_start(self)
   print("on_battle_start called")
end

function on_battle_end(self)
    print("on_battle_end called")
end

function on_spawn(self, tile) 
    print("on_spawn called")
end

function can_move_to(tile) 
    if tile:is_edge() then
        return false
    end

    return true
end

function on_delete(self)
    print("on_delete called")
end