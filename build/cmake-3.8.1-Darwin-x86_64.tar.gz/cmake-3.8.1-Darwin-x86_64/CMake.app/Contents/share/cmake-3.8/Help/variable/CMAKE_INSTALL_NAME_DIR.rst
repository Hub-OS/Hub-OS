CMAKE_INSTALL_NAME_DIR
----------------------

OS X directory name for installed targets.

``CMAKE_INSTALL_NAME_DIR`` is used to initialize the
:prop_tgt:`INSTALL_NAME_DIR` property on all targets.  See that target
property for more information.
