CMAKE_PROJECT_<PROJECT-NAME>_INCLUDE
------------------------------------

A CMake language file or module to be included by the :command:`project`
command.  This is is intended for injecting custom code into project
builds without modifying their source.
