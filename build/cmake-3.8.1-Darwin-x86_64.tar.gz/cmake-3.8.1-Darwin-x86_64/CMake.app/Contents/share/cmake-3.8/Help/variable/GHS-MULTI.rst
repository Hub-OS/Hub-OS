GHS-MULTI
---------

True when using Green Hills MULTI
