CMAKE_HOST_WIN32
----------------

``True`` on Windows systems, including Win64.

Set to ``true`` when the host system is Windows and on Cygwin.
