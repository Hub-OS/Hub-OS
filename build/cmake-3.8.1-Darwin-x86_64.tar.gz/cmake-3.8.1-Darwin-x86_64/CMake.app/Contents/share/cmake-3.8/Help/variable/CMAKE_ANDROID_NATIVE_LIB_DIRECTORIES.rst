CMAKE_ANDROID_NATIVE_LIB_DIRECTORIES
------------------------------------

Default value for the :prop_tgt:`ANDROID_NATIVE_LIB_DIRECTORIES` target
property.  See that target property for additional information.
